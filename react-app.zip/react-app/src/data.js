import React, {Component} from "react";
import App from "./App";

class data extends Component{
state = {
    employee: [
        {
            id:"1",
            name: "Jack",
            age: "34",
            DOB: "05-06-1967",
            salary: "4000",
            designation: "Software Engineer",
            image: "https://media.istockphoto.com/photos/smiling-indian-man-looking-at-camera-picture-id1270067126?k=20&m=1270067126&s=612x612&w=0&h=ZMo10u07vCX6EWJbVp27c7jnnXM2z-VXLd-4maGePqc=",
            department: "NCS"
        }
    ]
}

render() {
    return (
        <>
            <Display id={this.state.employee.id} age={this.state.employee.name} 
            DOB ={this.state.employee.DOB} salary={this.state.employee.salary} 
            designation = {this.state.arrOfObject} image={this.state.employee.image} 
            department={this.state.employee.department} />
            {/* <input ref={this.name} /> */}
        </>
    )
}
}
export default data;