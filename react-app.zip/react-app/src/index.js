require('file-loader?name=[name].[ext]!./index.html');
import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import AppGrocery from "./AppGrocery";

ReactDOM.render(<App/>, document.getElementById('app'));
