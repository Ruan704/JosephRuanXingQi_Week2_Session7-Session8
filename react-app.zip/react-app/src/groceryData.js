const data = {
  grocery: [
    {id: 1,name: "Apple", price: 1.2, },
    { id: 2, name: "Oranges",price: 2 },
    { id: 3, name: "Grapes", price: 0.5 },
  ]
}

export default data;
