// import React, {useState} from "react";
// import data from './Data';

// const App = () => {
//     const [isHovering, setIsHovering] = useState(false);

//     const MouseIn = () => {
//       setIsHovering(true);
//     };
  
//     const MouseOut = () => {
//       setIsHovering(false);
//     };
  
//     const dataList = data.employee.map((r) => {
//         return (
//               <span>  <div key={r.idCategory} style={{ color: "black", textAlign: "center" }}>
//                 <img src={r.image} alt="image" />
//                 <h4 onMouseOver={MouseIn} onMouseOut={MouseOut}>{r.name}</h4>
//                 {isHovering && (<ul style={{ border: "1px solid" }}>
//                 <h4>{"Date Of Birth: " + r.DOB}</h4>
//                 <h4>{"Employee Salary: " + r.salary}</h4>
//                 <h4>{"Employee Designation: " + r.designation}</h4>
//                 <h4>{"Employee Department: " + r.department}</h4>
//                 </ul> 
//                 )}
//                </div>  </span>
//         )
//     });

//     return (
//         <React.Fragment>
//             <h2>Employee Data</h2>
//             {dataList}
//         </React.Fragment>
//     );
//     };
// export default App;



import React from "react";
const App = (props) => {

  console.log(props);

  const { id,name,age,DOB,salary,designation,image,department } = props; 
  

    return (
      <>
          <p>{id}</p>
          <p>{name}</p>
          <p>{age}</p>
          <p>{DOB}</p>
          <p>{salary}</p>
          <p>{designation}</p>
          <p>{image}</p>
          <p>{department}</p>
      </>
  );
    };
export default App;