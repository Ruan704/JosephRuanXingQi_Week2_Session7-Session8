import React from "react";
import groceryData from './groceryData';

const AppGrocery = () => {
    console.log(groceryData.grocery);
    
    const dataList = groceryData.grocery.map(r => {
        return (
                <div key={r.id} style={{ color: "black", textAlign: "center" }}>
                <h4>{r.name}</h4>
                {/* <img src={r.image} alt="image" /> */}
                <h4>{"Grocery Price: $" + r.price}</h4>
               </div>     
        )
    });

    return (
        <React.Fragment>
            <h2>Grocery Data</h2>
            {dataList}
        </React.Fragment>
    );
    };
export default AppGrocery;



