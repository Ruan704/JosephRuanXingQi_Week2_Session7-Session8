import React from 'react';
import groceryData from './groceryData';
class ItemsList extends React.Component {
  render(){ 
    {var dataList = groceryData.grocery.map(r =>{
    return(
    <div id={r.id} key={r.id}>
       <><h3>{r.name}</h3>
       <h3>{r.price}</h3></>
       </div>
      )
    }); }
    return(
      
      <React.Fragment>
        <h2>Grocery Data</h2>
        {dataList}
      </React.Fragment>
    )
  }
}
export default ItemsList;